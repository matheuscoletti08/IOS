// Crie um programa que declare uma variável do tipo double e atribua a ela o valor 
// 3.1415. Em seguida, exiba o valor dessa variável na tela. 

var numerodecimal = 3.6598;
console.log(numerodecimal);