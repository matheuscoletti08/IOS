// Crie um programa que declare uma variável do tipo booleano e atribua a ela o valor 
// "true". Em seguida, exiba o valor dessa variável na tela. 

var boo = false;
console.log(boo);