// Crie um programa que declare duas variáveis do tipo inteiro e exiba o resultado da 
// soma dessas variáveis. 

var a = 19;
var b = 8;
var soma = a + b;
console.log("A soma é: " + soma);   