// Crie um programa que declare uma variável do tipo string e exiba seu conteúdo na 
// tela. 

var texto = "KKAKAKAKKA";
console.log(texto);